#include "lista.h"

/**
 *		front
 * 	_________________
 * 	|_____head______|
 * 	|_______________|
 * 	|_______________|
 * 	|_______________|
 *  |_____tail______|
 *
 * 		back
 **/


pos_t* createList(int first_value){

	
}


pos_t* readList(const char* filePath){
	FILE* file = fopen(filePath, "rb");

	
	return current;
}


void writeList(pos_t* head, const char* filePath){

	
}

int push_back(pos_t* head, int new_value){


}


int push_front(pos_t** head, int new_value){

}


int pop_front(pos_t **head){//Remueve el head!

}


int pop_back(pos_t* head){

	
}


int insertElement(pos_t** head, int pos, int new_value){


}


int removeElement(pos_t** head, int pos){
	
}


int freeList(pos_t* head){

	
}


int getElement(pos_t* head, int index, int* valid){
	   
 
}


int printElement(const int value){
	printf("%d \n", value);
	return 0;
}


void sort(pos_t* head, char dir){
	
	
}


void printList(pos_t* head){
	
}

